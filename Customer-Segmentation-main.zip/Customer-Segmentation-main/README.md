# Customer Segmentation 🛍️🛒 ![license](https://img.shields.io/github/license/Pegah-Ardehkhani/Customer-Segmentation.svg) ![releases](https://img.shields.io/github/release/Pegah-Ardehkhani/Customer-Segmentation.svg) <a href="https://colab.research.google.com/github/Pegah-Ardehkhani/Brain-MRI-Segmentation/blob/main/Customer%20Segmentation%20(Clustering).ipynb" target="_parent\"><img src="https://colab.research.google.com/assets/colab-badge.svg" alt="Open In Colab"/></a> [![nbviewer](https://img.shields.io/badge/render-nbviewer-orange.svg)](http://nbviewer.org/github/Pegah-Ardehkhani/Customer-Segmentation/blob/main/Customer%20Segmentation%20%28Clustering%29.ipynb)

<p align="center">
  <img width="500" height="250" src="https://sourcificconsulting.co.uk/wp-content/uploads/image19.gif">
</p>

## Dataset 📔

[Kaggle link: Customer Personality Analysis Data](https://www.kaggle.com/datasets/imakash3011/customer-personality-analysis)
